# L'Esprit Léger - Android wrapper

This project embeds `esprit_libre_stable_finale_beta_v5.html` as `app/src/main/assets/index.html` in a native Android WebView.

Build: `gradle assembleDebug`
Output: `app/build/outputs/apk/debug/app-debug.apk`
